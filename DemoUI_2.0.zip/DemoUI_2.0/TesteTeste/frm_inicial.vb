﻿Public Class frm_inicial

    Dim flag As Boolean = True


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If TimeOfDay.Hour > 19 Then
            lbl_hours.Text = TimeOfDay + " PM"
        ElseIf TimeOfDay.Hour < 9 Then
            lbl_hours.Text = TimeOfDay + " AM"

        End If
    End Sub

    Private Sub frm_inicial_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If flag = True Then
            PictureBox1.Image = TesteTeste.My.Resources.button_conectado
        Else
            PictureBox1.Image = TesteTeste.My.Resources.button_desconectado

        End If
        lbl_today.Text = Date.Today.ToLongDateString
        Timer1.Start()
    End Sub
End Class