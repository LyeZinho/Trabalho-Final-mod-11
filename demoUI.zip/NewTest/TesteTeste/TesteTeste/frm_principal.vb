﻿Public Class frm_principal
    Public MoveForm As Boolean
    Public MoveForm_MousePosition As Point
    Private flag As Boolean

    Public Sub MoveForm_MouseDown(sender As Object, e As MouseEventArgs) Handles _
    MyBase.MouseDown, pnl_mover.MouseDown, pnl_vertical.MouseDown, pic_mainlogo.MouseDown ' Add more handles here (Example: PictureBox1.MouseDown)

        If e.Button = MouseButtons.Left Then
            MoveForm = True
            Me.Cursor = Cursors.NoMove2D
            MoveForm_MousePosition = e.Location
        End If

    End Sub

    Public Sub MoveForm_MouseMove(sender As Object, e As MouseEventArgs) Handles _
    MyBase.MouseMove, pnl_mover.MouseMove, pnl_vertical.MouseMove, pic_mainlogo.MouseMove ' Add more handles here (Example: PictureBox1.MouseMove)

        If MoveForm Then
            Me.Location = Me.Location + (e.Location - MoveForm_MousePosition)
        End If

    End Sub

    Public Sub MoveForm_MouseUp(sender As Object, e As MouseEventArgs) Handles _
    MyBase.MouseUp, pnl_mover.MouseUp, pnl_vertical.MouseUp, pic_mainlogo.MouseUp ' Add more handles here (Example: PictureBox1.MouseUp)

        If e.Button = MouseButtons.Left Then
            MoveForm = False
            Me.Cursor = Cursors.Default
        End If
    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles PictureBox6.Click
        If MsgBox("Deseja realmente sair?", vbQuestion Or vbYesNo Or vbDefaultButton2, "Confirmação de saída") = vbYes Then
            Me.Close()
        Else
        End If

    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub


    Private Sub frm_principal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        flag = True
        lbl_today.Text = Date.Today.ToLongDateString
        Timer1.Start()
    End Sub

    Private Sub pic_sidemenudark_Click(sender As Object, e As EventArgs) Handles pic_sidemenudark.Click
        If flag = True Then
            pnl_vertical.Hide()
            flag = False
        Else
            pnl_vertical.Show()
            flag = True
        End If

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If TimeOfDay.Hour > 19 Then
            lbl_hours.Text = TimeOfDay + " PM"
        ElseIf TimeOfDay.Hour < 9 Then
            lbl_hours.Text = TimeOfDay + " AM"

        End If
    End Sub

    Private Sub pnl_vertical_Paint(sender As Object, e As PaintEventArgs) Handles pnl_vertical.Paint

    End Sub
End Class
